import time 
class Image_decoder:
        def __init__(self,image_name):
                self.end_hex = b"\x00\x00\x00\x00\x49\x45\x4e\x44\xae\x42\x60\x82" 
                self.image_name = image_name
                self.Bin = "b\'\'"
        def greeting()->str:
                print("""\n
                 ________________________________________
                |                                        |
                | ----Welcome to Cisco Image Decoder---- |
                |________________________________________|
                \n""".center(50))        
        def decoder(self) ->bin:
                try:
                        for i in range(0,101,10):
                                print(f"Loading {i}%")
                                time.sleep(0.5)      
                        with open(self.image_name,"rb") as image:
                                data = image.read()
                                offset = data.index(self.end_hex)
                                image.seek(offset+len(self.end_hex))
                                unpack =str(image.read())
                                image.close()
                                if unpack == self.Bin:
                                        print("""\n
                                         ________
                                        |        |
                                        | Failed |
                                        |________|
                                        \n""".center(50))
                                        print("\nExecution Failed no data exist\n")
                                else:
                                        print("""\n
                                                 ____________
                                                |            |
                                                | Successful |
                                                |____________|
                                                \n""".center(50))
                                        print(unpack[2:len(unpack)-1],'\n')
                except Exception as error:
                        print("""\n
                         ________
                        |        |
                        | Failed |
                        |________|
                        \n""".center(50))
                        print(error)
                        

Image_decoder.greeting()
file_name = input("Enter the image name to decode:-> ")
decode = Image_decoder(file_name)
decode.decoder()
input("Press Enter to exit")
